from itertools import count

from django.shortcuts import render, redirect
from .forms import *
from .models import TNotif, TReport, TUM
from django.urls import reverse_lazy
from django.core.exceptions import ValidationError
from django.views.generic.edit import FormView, CreateView, UpdateView, DeleteView
from django.views.generic import TemplateView
from django.views import View
from .Fnoti import *
from django.http import JsonResponse
from datetime import datetime, timedelta, date
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from xhtml2pdf import pisa
from django.template import loader
import PyPDF2
import os
from django.http import HttpResponse
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models.signals import post_save
from django.dispatch import receiver



DiasMas = 10
MESES = {
        'enero': 1, 'febrero': 2, 'marzo': 3, 'abril': 4, 'mayo': 5, 'junio': 6,
        'julio': 7, 'agosto': 8, 'septiembre': 9, 'octubre': 10, 'noviembre': 11, 'diciembre': 12
    }


def divstr(Strtxt, ini, fin):
    axt = ''
    p = Strtxt.find(ini)
    if p:
        txt = Strtxt[p + len(ini):]
    p = txt.find(fin)
    if p:
        axt = txt[:p]
    return axt

@login_required
def base(request):
    from .urls import urlpatterns
    sal = urlpatterns
    return render(request, "Base.html", {'base': sal})


class AddFile(FormView,LoginRequiredMixin):
    template_name = "add.html"
    form_class = FAddFile
    success_url = reverse_lazy('ListRepo')
    extra_context = {'is_report':True}

    def form_valid(self, form):

        def ReadReport(NotiTxt, UMs):
            Rep = TReport()
            Rep.ArTxt = '**************EQUIPO' + NotiTxt[:NotiTxt.find('\n\n')]
            Rep.Report = divstr(NotiTxt, 'No Reporte: ', '\n')
            Rep.tipo = divstr(NotiTxt, Rep.Report + '\n', ';')
            virus = NotiTxt[:NotiTxt.find('IP del HOST: ')].split('\\')[-1]
            Rep.archvirus = virus
            Rep.Ip = divstr(NotiTxt, 'IP del HOST: ', '\n')
            strfech = divstr(NotiTxt, 'FECHA: ', ' ')
            Rep.Focurren =datetime.strptime(strfech,"%Y/%m/%d").date()
            Rep.Finicio = datetime.now().date()
            Rep.Fvenc = Rep.Finicio + timedelta(days=DiasMas)
            Rep.accion = divstr(NotiTxt, 'ACCION: ', '\n')
            Rep.componente = divstr(NotiTxt, 'COMPONENTE: ', '\n')
            Rep.actualiza = divstr(NotiTxt, 'ACTUALIZACION: ', '\n')
            um = UMs.filter(IpMax__gte=Rep.Ip, IpMin__lte=Rep.Ip).first()
            Rep.UM = um
            return Rep

        upfile = form.cleaned_data['ArchRep']
        if upfile:  # try:
            bdUM = TUM.objects.all()
            if upfile.name.endswith('.txt'):
                redp = ReadReport(upfile.read().decode('utf-8'), bdUM)
                redp.save()
            elif upfile.name.endswith('.pdf'):
                pdf = PyPDF2.PdfReader(upfile)
                pag1 = pdf.pages[0].extract_text()
                noti = divstr(pag1,"N° ",'\n')
                parts = divstr(pag1,'La Habana, ','\n').split('de')
                fenvio = date(int(parts[2].strip()), MESES[parts[1].strip().lower()] ,int(parts[0].strip()))
                parts = divstr(pag1, 'del día ', '.').split('de')
                fvenc = date(int(parts[2].strip()), MESES[parts[1].strip().lower()], int(parts[0].strip()))
                BdNoti = TNotif.objects.get_or_create(
                    Notif=noti,
                )[0]
                BdNoti.Archivo = upfile
                BdNoti.save()
                txtpdf = ''
                for i in pdf.pages[1:]:
                    itxt = i.extract_text()
                    if not (itxt.find('***EQUIPO')>-1 or itxt.find('SITIO ORIGEN')>-1):
                        break
                    txtpdf +='\n'+ itxt
                lpdf = txtpdf.split('***EQUIPO')
                for i in lpdf[1:]:
                    redp = ReadReport(i,bdUM)
                    redp.Notif = BdNoti
                    redp.Fvenc = fvenc
                    redp.Finicio = fenvio
                    redp.save()
        return super().form_valid(form)


class AddUM(CreateView):
    template_name = "add.html"
    model = TUM
    form_class = FAddUM
    success_url = reverse_lazy('ListUM')
    extra_context = {'is_um':True,'title':'Titulo'}

    def form_valid(self, form):
        new = form.save(commit=False)
        todas = TUM.objects.all()
        for i in todas:
            if i.Overload(new):
                form.add_error(None, ValidationError('coincide  con la UM: ' + str(i.Num)))
                return self.form_invalid(form)
        return super().form_valid(form)

@receiver(post_save,sender=TUM)
def saveUm(sender,instance,created,*args,**kwargs):
    if created:
        reps = TReport.objects.all()
        for i in reps:
            if instance.IP_in(i.Ip):
                i.UM = instance
                i.save()


class UpdateUM(UpdateView):
    template_name = "add.html"
    model = TUM
    form_class = FAddUM
    success_url = reverse_lazy('ListUM')
    extra_context = {'is_um':True}

    def form_valid(self, form):
        new = form.save(commit=False)
        todas = TUM.objects.all()
        if (new.UMMayor != None):
            if new.UMMayor.Num == new.Num:
                form.add_error(None, ValidationError('No puede ser Hija de si misma '))
                return self.form_invalid(form)
        old = todas.get(pk=new.pk)
        if not (new.IpMin == old.IpMin and new.IpMax == old.IpMax):
            for i in todas:
                if i.Overload(new) and not(i.pk == new.pk)  :
                    form.add_error(None, ValidationError('coincide  con la UM: ' + str(i.Num)))
                    return self.form_invalid(form)
            reps = TReport.objects.all()
            for i in reps:
                if new.IP_in(i.Ip):
                    i.UM = new
                    i.save()
                else:
                    if new==i.UM:
                        i.UM = None
                        i.save()
        return super().form_valid(form)


class DelUm(DeleteView):
    template_name = "delete.html"
    model = TUM
    success_url = reverse_lazy('ListUM')
    extra_context = {'is_um':True}


class ListRepo(ListView,LoginRequiredMixin):
    model = TReport
    paginate_by = 20
    template_name = "ListReport.html"
    extra_context = {
        "LisEstad": VEstado,
        'is_report': True,
    }

    def get_queryset(self, **kwargs):
        query = super().get_queryset(**kwargs)
        hoy = date.today()
        query.filter(Fvenc__lte=hoy).exclude(Estado__in=[0, 3]).update(Estado=0)
        return query


class ListUM(ListView):
    model = TUM
    paginate_by = 20
    template_name = "ListUM.html"
    extra_context = {'is_um':True}


class UpReport(View):
    def post(self, request, *args, **kwargs):
        estado = request.POST.get('Estado')
        id = request.POST.get('id')
        try:
            BDReport = TReport.objects.get(id=id)
            BDReport.Estado = estado
            BDReport.save()
            return JsonResponse({'status': 'success', 'Estado': BDReport.Estado})
        except:
            pass


class DetalRepo(DetailView):
    model = TReport
    template_name = "detal.html"
    extra_context = {'is_report':True}


def CrearResp(request,report):

    def render_to_pdf(template_src, context_dict):
        template = loader.get_template(template_src)
        html = template.render(context_dict)
        pdf = pisa.CreatePDF(html)
        return pdf

    repor = TReport.objects.filter(id=report).first()
    strfirm = request.GET.get('firmas')
    sfmain = request.GET.get('fmain')
    if (sfmain):
        fmain = Tfirman.objects.filter(id=sfmain).first()
        if not(strfirm):
            strfirm=sfmain
        else:
            if not (sfmain in strfirm):
                    strfirm +=  sfmain+','+strfirm
        firmas = Tfirman.objects.filter(id__in=strfirm.split(','))
    else:
        firmas,fmain ='',''

    if request.method == 'GET':
        form = FRespNoti()
        return render(request, 'ResForm.html', {
            "form": form,
            "report": repor,
            'firmas':firmas,
            'fecha':datetime.now().date(),
            "fmain": fmain,
            'request': request,
            'is_report': True,
        })

    if request.method == 'POST':
        form = FRespNoti(request.POST)
        if form.is_valid():
           if form:
                cont = {
                    "base_url":f"{request.scheme}://{request.get_host()}",
                    "fecha":form.cleaned_data["fecha"],
                    "report":repor,
                    'firmas':firmas,
                    "fmain": fmain,
                    "oficina":form.cleaned_data["oficina"],
                    "registro": form.cleaned_data["registro"],
                    "violacion":form.cleaned_data["violacion"],
                    'medios':form.cleaned_data['medios'],
                    'acciones':form.cleaned_data['acciones'],
                    'causas':form.cleaned_data['causas'],
                    'conclusiones':form.cleaned_data['conclusiones'],
                    'recomendaciones':form.cleaned_data['recomendaciones'],
                    'is_report': True,
                }
                pdf = render_to_pdf('ResForm.html', cont)
                if pdf.err:
                    return HttpResponse('Error while generating PDF')
                path = os.path.join(os.getcwd(),"media", 'pdfs', str(datetime.now().year))
                if not os.path.exists(path):
                    os.makedirs(path)
                a = repor.Report.replace(' ','')
                a = a[a.find('/')+1:]
                arch=  os.path.join(path,f"{a}.pdf")
                with open(arch, 'wb+') as f:
                    f.write(pdf.dest.getvalue())
                    repor.ArResp = arch
                    repor.Estado = 3
                    repor.save()
                    V = Vmax.objects.get(id==1)
                    V.val = int(form.cleaned_data['registro'])
                return render(request, 'ResForm.html',cont)
           #except:
            #    form.add_error("error al responder el reporte")
    return render(request, 'ResForm.html',{'form':form,'is_report':True})


class AddFirm(CreateView):
    template_name = "add.html"
    model = Tfirman
    form_class = FAddFirm
    extra_context = {'img':True,'is_firma':True}
    success_url = reverse_lazy('ListFirm')


class ListFirm(ListView):
    model = Tfirman
    paginate_by = 20
    template_name = "ListFirm.html"
    extra_context = {'is_firma':True}

class DelFirm(DeleteView):
    template_name = "delete.html"
    model = Tfirman
    success_url = reverse_lazy('ListFirm')
    extra_context = {'is_firma':True}

class UpdateFirm(UpdateView):
    template_name = "add.html"
    model = Tfirman
    form_class = FAddFirm
    success_url = reverse_lazy('ListUM')
    extra_context = {'is_firma':True}

def ResRep(request,report):
    rep = TReport.objects.get(pk=report)
    if request.method == 'GET':
        form = FResRepo(instance=rep)
    if request.method == 'POST':
        form = FResRepo(request.POST,request.FILES,instance=rep)
        if form.is_valid():
            if (form.cleaned_data['opc']=='crear'):
                fmain=form.cleaned_data['Fmain']
                url = reverse_lazy('RespRepo', kwargs={'report': str(report)}) + f'?fmain={fmain.pk}'
                Firmas=form.cleaned_data['Firmas']
                url+= ("&firmas="+','.join(str(i.pk) for i in Firmas)) if Firmas else ''
                return redirect(url)
            else:
                form.save()
    return render(request, 'ResRep.html', {'form': form,'is_report':True})


