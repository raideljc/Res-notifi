from .models import *
from django.contrib import admin

@admin.register(TReport)
class ReportAdmin(admin.ModelAdmin):
    list_display = ['id','Report','Ip','UM','Finicio','tipo','archvirus',
                    'Notif','accion','componente','actualiza']

@admin.register(TNotif)
class NotiAdmin(admin.ModelAdmin):
    list_display = ['Notif','Archivo']

@admin.register(TUM)
class tuAdmin(admin.ModelAdmin):
    list_display = ['Num','Nombre','UMMayor','IpMin','IpMax']

@admin.register(Tfirman)
class tFirmAdmin(admin.ModelAdmin):
    list_display = ['id','nomb','grado','firma']