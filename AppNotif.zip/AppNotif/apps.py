from django.apps import AppConfig


class AppnotifConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppNotif'

    #def ready(self):
      #  import AppNotif.models