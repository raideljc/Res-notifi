from django.db import models
import ipaddress
VEstado = [
        (0, 'Pendiente'),
        (1,'Recibido'),
        (2,'enviado'),
        (3,'Resuelto'),
    ]

class TReport(models.Model):
    Report = models.CharField(max_length=25,blank=True)
    Finicio = models.DateField(null=True)
    Focurren = models.DateField(null=True)
    Fvenc = models.DateField(null=True)
    tipo = models.CharField(max_length=40, blank=True)
    accion = models.CharField(max_length=25)
    componente = models.CharField(max_length=40)
    archvirus = models.CharField(max_length=20)
    actualiza = models.CharField(max_length=25)
    UM = models.ForeignKey('TUM', blank=True, null=True, on_delete=models.PROTECT)
    Ip = models.GenericIPAddressField(null=True)
    Estado = models.PositiveSmallIntegerField(choices=VEstado,default=1,blank=True)
    ArResp = models.FileField(blank= True,upload_to='notific')
    ArTxt = models.TextField(blank=True)
    Notif = models.ForeignKey('TNotif', blank = True, on_delete=models.CASCADE, null=True)

    class Meta:
        ordering = ['Estado',"Finicio"]
        unique_together=['Report','Notif']

    def __str__(self):
        return self.Report



class TNotif(models.Model):
    Notif = models.CharField(max_length=15)
    Archivo = models.FileField(upload_to='notific',blank=True,null=True)

    def __str__(self):
        return self.Notif


class TUM(models.Model):
    Num = models.PositiveSmallIntegerField(blank=True)
    Nombre = models.CharField(max_length=30,blank=True)
    UMMayor = models.ForeignKey('self',blank=True,on_delete=models.CASCADE, null=True)
    IpMin = models.GenericIPAddressField(null=True)
    IpMax = models.GenericIPAddressField(null=True)

    class Meta:
        unique_together=['Num','Nombre']

    def __str__(self):
        return 'UM '+str(self.Num)

    def Overload(self,otro):
        return (ipaddress.ip_address(self.IpMin) <= ipaddress.ip_address(otro.IpMax)) and (ipaddress.ip_address(self.IpMax) >= ipaddress.ip_address(otro.IpMin) )

    def IP_in(self,IP):
        ipmin = ipaddress.ip_address(self.IpMin)
        ipmax = ipaddress.ip_address(self.IpMax)
        ip= ipaddress.ip_address(IP.strip())
        return ( ipmin <= ip <= ipmax)



class Tfirman(models.Model):
    firma = models.ImageField(upload_to='firma/', blank=True, null=True)
    nomb = models.CharField(max_length = 60)
    grado = models.CharField(max_length=14, blank=True, null=True)
    cargo = models.CharField(max_length=60, blank=True, null=True)
    def __str__(self):
        return self.grado +"  "+self.nomb

    class Meta:
        unique_together=['nomb','grado','cargo']

class Vmax(models.Model):
    val = models.PositiveIntegerField(default=0)