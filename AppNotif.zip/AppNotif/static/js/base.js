function  seletopc(selec) {
    return selec.options.length
}
