from AppNotif import views
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.base,name='base'),
    path('repos/list/', views.ListRepo.as_view(), name='ListRepo'),
    path('add/', views.AddFile.as_view(), name='AddFile'),
    path('repos/detal/<pk>/', views.DetalRepo.as_view(), name='DetalRepo'),
    path('repos/resp/<int:report>/', views.CrearResp, name='RespRepo'),
    path('repos/preg/<int:report>/', views.ResRep, name='PregRepo'),
    path('repos/up/', views.UpReport.as_view(), name='UpRepo'),

    path('firma/add/', views.AddFirm.as_view(), name='AddFirm'),
    path('firma/up/<pk>/', views.UpdateFirm.as_view(), name='UpFirm'),
    path('firma/del/<pk>/', views.DelFirm.as_view(), name='DelFirm'),
    path('firma/list/', views.ListFirm.as_view(), name='ListFirm'),

    path('um/add/', views.AddUM.as_view(), name='AddUM'),
    path('um/up/<pk>/', views.UpdateUM.as_view(), name = 'UpUM'),
    path('um/del/<pk>/', views.DelUm.as_view(), name = 'DelUM'),
    path('um/list/', views.ListUM.as_view(), name='ListUM'),

]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)