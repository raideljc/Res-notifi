from builtins import filter

from django import forms
from .models import *
from datetime import datetime

class FAddFile(forms.Form):
    ArchRep = forms.FileField(label="archivo")

class FAddFirm(forms.ModelForm):
    class Meta:
        fields = ["firma", "nomb", "grado", "cargo"]
        model = Tfirman


class FAddUM(forms.ModelForm):
    class Meta:
        model = TUM
        fields = ['Nombre','Num','UMMayor','IpMin','IpMax']
        widgets = {
            'IpMin': forms.TextInput(attrs={'placeholder':'xxx.xxx.xxx.xxx',
                                            'pattern':"^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$" }),
            'IpMax': forms.TextInput(attrs={'placeholder': 'xxx.xxx.xxx.xxx',
                                            'pattern':"^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"}),
        }

        def clean(self):
            datos = super().clean()
            min = datos.get('IpMin')
            max = datos.get('IpMax')
            if min > max:
                raise forms.ValidationError('IpMin >ipMax')
            return datos


class FRespNoti(forms.Form):
    violacion = forms.CharField(widget=forms.Textarea,required=False)
    medios = forms.CharField(widget=forms.Textarea,required=False)
    acciones = forms.CharField(widget=forms.Textarea,required=False)
    causas  = forms.CharField(widget=forms.Textarea,required=False)
    conclusiones = forms.CharField(widget=forms.Textarea,required=False)
    recomendaciones  = forms.CharField(widget=forms.Textarea,required=False)
    oficina = forms.CharField(required=False)
    registro = forms.IntegerField(required=False)
    fecha =forms.DateField(initial=datetime.now().date(),widget=forms.TextInput(attrs={'type':'date'}))
    registro = forms.IntegerField(required=False)
    def __init__(self,*args,**kwargs):
        super(FRespNoti, self).__init__(*args,**kwargs)
        Vm = Vmax.objects.get_or_create(id==1)
        #self.fields['reg'].initial = Vm.val

class FResRepo(forms.ModelForm):
    opciones = [
        ('up','subir respuesta'),
        ('crear','responder'),
    ]
    #file = forms.FileField(label="archivo",required=False)
    Fmain = forms.ModelChoiceField(Tfirman.objects.all(),required=False)
    Firmas = forms.ModelMultipleChoiceField(Tfirman.objects.all(),required=False)
    opc = (forms.ChoiceField(choices=opciones,widget=forms.RadioSelect(attrs={'onchange':'change()'}),initial='up'))
    class Meta:
        model=TReport
        fields = [ 'ArResp']
